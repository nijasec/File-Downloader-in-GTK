#include <gtk/gtk.h>
#include <curl/curl.h>

struct userdata{
    
    char *st;
    double t;
    
};
GtkBuilder *builder;
GtkEntry *text;
GtkWidget *Bar;
 size_t my_write_func(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
  return fwrite(ptr, size, nmemb, stream);
}
 
size_t my_read_func(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
  return fread(ptr, size, nmemb, stream);
}
 double count;
  GtkProgressBar *pbar;
    GtkLabel *status;
    int updateProgress(gpointer gp)
    {
   struct userdata *udata=(struct userdata*)gp;
   gtk_progress_bar_set_text(pbar,udata->st);
   gtk_progress_bar_set_fraction(pbar,udata->t);  
   g_free(udata->st);
    g_free(gp);
    
   return 0;     
    }
int my_progress_func(GtkWidget *bar,
                     double t, /* dltotal */ 
                     double d, /* dlnow */ 
                     double ultotal,
                     double ulnow)
{
//  g_print("\n%f / %f (%f %)\n", d, t, d/t);
  
 double temp=0;
 count=count+1;
  if(t>0)
  temp=d/t;
  
  char st[1000];
  sprintf(st,"%.2fKB",d/1024);
  struct userdata *udata=malloc(sizeof(struct userdata));
  udata->t=temp;
  udata->st=strdup(st);
   
 g_idle_add(updateProgress,udata);
  
  return 0;
}

void *download_thread(void *ptr)
{
  CURL *curl;
 count=0;
  curl = curl_easy_init();
  if(curl) {
    gchar *url = ptr;
g_print("\n url:%s",url);
    const char *filename = "test.txt";
    FILE *outfile = fopen(filename, "wb");
 gtk_label_set_text(status,"Downloading...");
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, outfile);
    curl_easy_setopt(curl,CURLOPT_CAINFO,"ca-bundle.crt");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_write_func);
    //curl_easy_setopt(curl, CURLOPT_READFUNCTION, my_read_func);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_PROGRESSFUNCTION, my_progress_func);
    curl_easy_setopt(curl, CURLOPT_PROGRESSDATA, pbar);
 
    curl_easy_perform(curl);
    gtk_label_set_text(status,"Finished");
    fclose(outfile);
    /* always cleanup */ 
    curl_easy_cleanup(curl);
  }
 
  return NULL;
}

   
    
int main(int argc, char *argv[])
{
	GtkWidget * window;
	GdkPixbuf * pixbuf;
	gtk_init( & argc, & argv);
	curl_global_init(CURL_GLOBAL_ALL);
	GError * error = NULL;
	pixbuf = gdk_pixbuf_new_from_resource("/images/appicon.png", & error);
	if (pixbuf == NULL)
	  g_print("pixbuf is nhull");
	if (error != NULL) {
	  g_printerr("Unable to read file: %s\n", error -> message);
	  g_error_free(error);
	  //return 0;
	}

    builder=gtk_builder_new_from_resource("/glades/main.glade");
    window=GTK_WIDGET(gtk_builder_get_object(builder,"appwindow"));
       text=GTK_ENTRY(gtk_builder_get_object(builder,"durl"));
       status=GTK_LABEL(gtk_builder_get_object(builder,"status"));
       pbar=GTK_PROGRESS_BAR(gtk_builder_get_object(builder,"progressbar"));
       
	//window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_progress_bar_set_show_text (pbar,1);

	g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);
    gtk_window_set_title(GTK_WINDOW(window),"Downloader");
    gtk_window_set_icon(GTK_WINDOW(window),pixbuf);
	gtk_widget_show (window);
    gtk_builder_connect_signals(builder,NULL);
	gtk_main ();

	return 0;
}
G_MODULE_EXPORT
void on_download_clicked()
{
  const char *txt=  gtk_entry_get_text(text);
    char *tx=strdup(txt);
   g_print("btn clicked and text is %s",tx);
   GThread *start_testing_thread;
   start_testing_thread = g_thread_new("", &download_thread,tx);

}