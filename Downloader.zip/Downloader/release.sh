mkdir release
cp firstapp.exe release/
cd release
ldd firstapp.exe | grep '\/mingw.*\.dll' -o | xargs -I{} cp "{}" .
mkdir lib
cd ..

